//
//  LTViewControllerBackground.swift
//  VPNOn
//
//  Created by Lex on 1/18/15.
//  Copyright (c) 2017 lexrus.com. All rights reserved.
//

import UIKit

class LTViewControllerBackground: UIView
{

}
